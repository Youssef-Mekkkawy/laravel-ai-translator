<?php

namespace YoussefMekkkawy\LaravelAiTranslator\Tests;

use Orchestra\Testbench\TestCase as Orchestra;
use YoussefMekkkawy\LaravelAiTranslator\LaravelAiTranslatorServiceProvider;

class TestCase extends Orchestra
{
    protected function setUp(): void
    {
        parent::setUp();

        // Additional setup can go here
    }

    /**
     * Get package providers.
     *
     * @param  \Illuminate\Foundation\Application  $app
     * @return array<int, class-string>
     */
    protected function getPackageProviders($app)
    {
        return [
            LaravelAiTranslatorServiceProvider::class,
        ];
    }

    /**
     * Define environment setup.
     *
     * @param  \Illuminate\Foundation\Application  $app
     * @return void
     */
    protected function getEnvironmentSetUp($app)
    {
        // Setup default database to use sqlite :memory:
        $app['config']->set('database.default', 'testing');
        $app['config']->set('database.connections.testing', [
            'driver'   => 'sqlite',
            'database' => ':memory:',
            'prefix'   => '',
        ]);

        // Setup package config for testing
        $app['config']->set('ai-translator.driver', 'deepl');
        $app['config']->set('ai-translator.languages', ['en', 'ar', 'fr']);
        $app['config']->set('ai-translator.default_language', 'en');
    }

    /**
     * Helper to create a temporary test directory
     */
    protected function getTempDirectory(): string
    {
        return __DIR__.'/temp';
    }

    /**
     * Helper to create test language files
     */
    protected function createTestLanguageFile(string $lang, string $file, array $content): void
    {
        $path = $this->getTempDirectory()."/lang/{$lang}";
        
        if (!file_exists($path)) {
            mkdir($path, 0755, true);
        }

        file_put_contents(
            "{$path}/{$file}.php",
            '<?php return ' . var_export($content, true) . ';'
        );
    }

    /**
     * Clean up test files
     */
    protected function tearDown(): void
    {
        $tempDir = $this->getTempDirectory();
        
        if (file_exists($tempDir)) {
            $this->deleteDirectory($tempDir);
        }

        parent::tearDown();
    }

    /**
     * Recursively delete a directory
     */
    protected function deleteDirectory(string $dir): void
    {
        if (!file_exists($dir)) {
            return;
        }

        $files = array_diff(scandir($dir), ['.', '..']);
        
        foreach ($files as $file) {
            $path = "{$dir}/{$file}";
            is_dir($path) ? $this->deleteDirectory($path) : unlink($path);
        }

        rmdir($dir);
    }
}
